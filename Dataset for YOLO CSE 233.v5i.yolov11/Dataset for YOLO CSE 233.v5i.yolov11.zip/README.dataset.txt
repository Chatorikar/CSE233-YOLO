# Dataset for YOLO CSE 233  > 2025-03-19 10:53pm
https://universe.roboflow.com/yolo-rh90o/dataset-for-yolo-cse-233

Provided by a Roboflow user
License: CC BY 4.0

